#define IF 		257
#define THEN 		258
#define ELSE 		259
#define ID		260
#define NUMERO		261
#define MAYOR_QUE 	262
#define MAYOR_IGUAL	263

