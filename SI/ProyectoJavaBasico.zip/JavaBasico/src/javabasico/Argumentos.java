/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javabasico;

/**
 *
 * @author in2gasae
 */
public class Argumentos {
    
    public static void main( String args[] ) {
        for( int i=0; i < args.length; i++ )
            System.out.println( args[i] );
            
    }
}
